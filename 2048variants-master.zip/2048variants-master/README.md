# 2048 Variants
A list of 2048 Variants.
